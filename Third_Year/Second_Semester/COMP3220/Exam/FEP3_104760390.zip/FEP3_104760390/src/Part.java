/**
 * This will be used to count the individual parts that are not assembled. Like bolt, nut and panel
 * 104760390
 * @author Andrea Bonato
 *
 */
public class Part extends Item{

	//This will be used to assign the super class values
	public Part(String description, double cost) {
		super(description, cost);
	}
	
}
