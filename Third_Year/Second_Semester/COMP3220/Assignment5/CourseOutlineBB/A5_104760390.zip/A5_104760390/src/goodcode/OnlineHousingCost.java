/* Class implements HousingCost for the online housing cost instance
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public class OnlineHousingCost implements HousingCost {
	//Doesnt really need the courseSize
	//Return the same string in each case
	public String calculateHousingCost(String courseSize) {
		return "No Housing Cost but you need a high speed internet connection";
	}
}
