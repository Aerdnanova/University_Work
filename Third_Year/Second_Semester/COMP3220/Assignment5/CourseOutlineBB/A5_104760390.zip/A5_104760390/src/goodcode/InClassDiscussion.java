/* Class implements DiscussionBoard
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public class InClassDiscussion implements DiscussionBoard{
	//returns string to be print for an inclass discussion board
	public String setupDiscussionBoard() {
		return "In class discussion\n";
	}
}
