/* Class implements OfficeHour for the Inclass outline type
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public class InPersonOfficeHour implements OfficeHour{
	
	//Returns a string to be printed
	public String setAndDisplayOfficeHour() {
		
		return "Office hour: EH-3146\n";
	}
}
