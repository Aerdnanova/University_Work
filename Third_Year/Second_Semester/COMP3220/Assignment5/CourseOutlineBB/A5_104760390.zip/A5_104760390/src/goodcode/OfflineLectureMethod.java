/* Class implements lecture method for the offline lectures
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public class OfflineLectureMethod implements LectureMethod {
	
	//Return string to be printed out
	public String displayLectureMethod() {
		
		return "Lecture Type: Inclass\n";
	}
}
