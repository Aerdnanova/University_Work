/* Class used to be implemented in each online and offline instance
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

//This will be used to be rewritten later on
public interface CourseFee {
	public String estimatedCourseFee(String courseSize);
}
