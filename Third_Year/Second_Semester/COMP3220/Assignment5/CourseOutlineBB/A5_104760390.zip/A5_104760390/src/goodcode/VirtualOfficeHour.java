/* Class implements OfficeHour in the online instances
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public class VirtualOfficeHour implements OfficeHour {
	
	//Returns a string used to print
	public String setAndDisplayOfficeHour() {
		
		return "Office hour: on Blackboard\n";
	}
}
