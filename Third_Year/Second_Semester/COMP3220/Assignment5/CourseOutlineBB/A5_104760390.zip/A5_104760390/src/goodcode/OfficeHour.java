/* Class used to determine officeHour for each class that implements it
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public interface OfficeHour {
	//Will be rewritten
	public String setAndDisplayOfficeHour();
}
