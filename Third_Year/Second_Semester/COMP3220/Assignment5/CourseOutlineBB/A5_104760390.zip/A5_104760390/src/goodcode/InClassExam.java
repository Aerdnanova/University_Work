/* Class implements ExamType for inclass outlines
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public class InClassExam implements ExamType {
	
	//Returns a string to be printed
	public String setExamType() {
		return "In class final exam\n";
	}
}
