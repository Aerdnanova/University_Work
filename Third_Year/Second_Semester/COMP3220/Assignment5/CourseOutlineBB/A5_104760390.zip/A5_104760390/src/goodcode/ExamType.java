/* Class used be implemented in the online vs offline exam types
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public interface ExamType {
	//To be rewritten in the offline vs online exam type classes
	public String setExamType();
}
