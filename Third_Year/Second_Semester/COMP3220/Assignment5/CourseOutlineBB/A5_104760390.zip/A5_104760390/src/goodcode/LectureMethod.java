/* Class used to implement between lecture methods (online vs offline)
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public interface LectureMethod {
	//To be rewritten in classes that implement LectureMethod
	public String displayLectureMethod();
}
