/* Class used in the implementation of the online vs offline discussion boards
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public interface DiscussionBoard {
	//Will be rewritten in classes that implment this
	public String setupDiscussionBoard();
}
