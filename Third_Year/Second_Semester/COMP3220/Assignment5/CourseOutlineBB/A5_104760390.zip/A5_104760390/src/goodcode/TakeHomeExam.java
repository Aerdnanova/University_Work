/* Class implements examType for the offline version
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public class TakeHomeExam implements ExamType{
	
	//Returned string used to print
	public String setExamType() {
		return "Take home final exam\n";
	}
}
