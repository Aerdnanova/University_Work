/* Class used in CourseOutline
 * Andrea Bonato
 * 104760390
 * */

package goodcode;

public class BBDiscussionBoard implements DiscussionBoard{
	//To print if the course is online, no matter is it is half class or full
	public String setupDiscussionBoard() {
		return "Use discussion board on Blackboard\n";
	}
}
