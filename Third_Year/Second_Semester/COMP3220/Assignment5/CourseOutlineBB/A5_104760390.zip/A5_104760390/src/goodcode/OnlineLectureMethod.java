/* Class implements Lecture Method for the online lecture instance
 * Andrea Bonato
 * 104760390
 * */
package goodcode;

public class OnlineLectureMethod implements LectureMethod {
	
	//Return string used to print
	public String displayLectureMethod() {
		
		return "Lecture Type: Online\n";
	}
}
