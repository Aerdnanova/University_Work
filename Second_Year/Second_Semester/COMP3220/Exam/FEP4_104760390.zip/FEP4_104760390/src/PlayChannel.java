/**
 * This will be used and implemented in the Follower so that Follower can implement the play() method 
 * 104760390
 * @author Andrea Bonato
 * */
public interface PlayChannel {
	
	public void play();
		
}
